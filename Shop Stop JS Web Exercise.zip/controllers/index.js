const home = require('./home');
const product = require('./product');
const category = require('./category');
const user = require('./user');

module.exports = {
    home,
    product,
    category,
    user
}