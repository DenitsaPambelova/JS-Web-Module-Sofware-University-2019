# Shop-Stop
“Shop Stop” is very simple product catalog website (like OLX, Amazon – but simpler 😊). The application will consist of users, products and categories. Each user can register, login and logout. Users also can create, buy, edit or delete a product. Each product has a category in which it is specified. Site will implement of searching for a product by the product’s name or category.
